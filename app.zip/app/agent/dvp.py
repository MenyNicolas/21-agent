import pandas as pd

import agent_BJ

main_joueur = [11, 7]
carte_dealer = 9

print(agent_BJ.agent_BJ(4, [], main_joueur, [carte_dealer, 10], 0, [2, 3, 9]))